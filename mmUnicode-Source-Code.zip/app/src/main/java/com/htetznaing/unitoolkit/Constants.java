package com.htetznaing.unitoolkit;

public class Constants {
    public static String CONTACTS="contacts",VIDEOS="videos",AUDIOS="audios", IMAGES ="images",CUSTOM="custom",MP3="mp3";
}
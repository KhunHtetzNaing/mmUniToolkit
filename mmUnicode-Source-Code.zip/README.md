
# mmUniToolkit    
 ဇော်ဂျီဖြင့်ရေးသားထားသော ဖုန်းအဆက်အသွယ်များ၊ ဖိုင်အမည်များကို  
  ယူနီကုဒ်သို့ပြောင်းလဲပေးနိုင်သော Tool ဖြစ်ပါသည်။  
  
## လုပ်ဆောင်ချက်များ  
  
 - [x] Contacts  
 - [x] Files name  
 - [x] Audio tag (title, artist, lyrics)  
  
## လိုအပ်နေသေးသောလုပ်ဆောင်ချက်များ  
  
 - [ ] SD Card အတွင်းရှိ ဖိုင်အမည်များအားပြောင်းလဲပေးခြင်း  
 - [ ] Notes (Colornote,Keep) အတွင်ရှိစာများအား ယူနီကုဒ်သို့ပြောင်းလဲပေးခြင်း  
 - [ ] APK name,database များအား ယူနီကုဒ်သို့ပြောင်းလဲပေးခြင်း  
  
**ကျန်တဲ့လိုအပ်တာလေးတွေ မည်သူမဆိုထပ်ဖြည့်စွက်နိုင်ပါတယ်။    
Senior မဟုတ်သည့်အတွက် ကုဒ်တွေကရှုပ်ပွနေပါတယ် 😁**

## အသုံးပြုထားသော Library များ

 - [Rabbit Converter](https://github.com/Rabbit-Converter/Rabbit)
 -  [Myanmar Tools](https://github.com/google/myanmar-tools)
 -  [Jaudiotagger](https://github.com/AdrienPoupa/jaudiotagger)
 -  [NoNonsense-FilePicker](https://github.com/spacecowboy/NoNonsense-FilePicker)
